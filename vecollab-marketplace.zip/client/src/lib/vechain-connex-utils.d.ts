declare module '@vechain.energy/connex-utils' {
  export const utils: any;
}